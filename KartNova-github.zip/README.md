# Kart Nova

**Kart Nova** は、Three.jsで作った日本語対応のブラウザ3Dカートレースゲームです。オリジナル動物レーサー、3つのオリジナルコース、ローカルCPUライバル、ドリフト、4種類のアイテムを使って3周のレースを走ります。外部の著作権ゲーム素材は使用していません。

## 起動方法

```bash
cd /home/ubuntu/kartnova
pnpm install
PORT=3000 HOST=0.0.0.0 pnpm dev
```

ブラウザで `http://localhost:3000/` を開いてください。プロダクション相当の確認は以下です。

```bash
pnpm typecheck
pnpm test
pnpm build
pnpm smoke
```

`pnpm smoke` はChromiumでタイトル、キャラクター選択、コース選択、走行、ドリフト、ポーズ、ゴール、結果画面まで通し、`shots/` に確認用スクリーンショットを出力します。

## 操作

| キー | 操作 |
| --- | --- |
| `W` / `↑` | アクセル |
| `S` / `↓` | ブレーキ・バック |
| `A` / `←` | 左旋回 |
| `D` / `→` | 右旋回 |
| `Shift` | ドリフト。旋回と同時に押すとドリフトゲージが溜まり、成功時に加速 |
| `Space` | 所持アイテムを使用 |
| `Esc` | レース中のポーズ |

壁や障害物に衝突すると減速します。コース外へ落ちた場合は、直前のコースラインへ自動復帰します。

## ゲーム内容

- **レース進行**：3周制、スタートカウントダウン、順位、速度、ラップ、タイマー、ゴール後の順位とタイム。
- **CPU**：コースのウェイポイントに沿って走る4台のライバル。スリップ、障害物、周回判定、順位判定に対応。
- **アイテム**：ブースト、スライムボール、シールド、ミステリーボックス。コース上のアイテムボックスに接触すると取得できます。
- **収集物**：コインを配置。取得時に効果音とHUDトーストを表示します。
- **ドリフト**：Shift＋旋回でゲージが上がり、一定時間以上のドリフトで短い加速を発生します。
- **選択画面**：ルゥ・フォックス、ミミ・パンダ、ポル・カワウソ、キキ・ハリネズミの4キャラクターと、5色のカートカラー。
- **コース**：グリーンヒル、サンセットシティ、スカイレインボー。各コースにスタート／ゴールライン、コーナー、壁、障害物、アイテム、コインがあります。
- **音**：Web Audio APIによるオリジナルの簡易BGM、エンジン音、UI音、アイテム音、衝突音。

## 主なファイル

| パス | 役割 |
| --- | --- |
| `src/game/game.ts` | コース生成、カート走行、CPU、衝突、周回、アイテム、カメラ、3D演出 |
| `src/main.ts` | Renderer、Input、GameLoop、UIの接続と画面遷移 |
| `src/ui/ui.ts` | 日本語のタイトル、選択、操作説明、HUD、ポーズ、結果画面 |
| `src/styles/main.css` | ネオン・サーキット調のレスポンシブUI |
| `src/engine/loop.ts` | 固定シミュレーションループと補間レンダリング |
| `src/engine/input.ts` | キーボード入力とキーリピート防止 |
| `src/engine/renderer.ts` | Three.js Renderer、カメラ、品質設定 |
| `src/engine/audio.ts` | Web AudioのBGMと効果音 |
| `assets/models/` | Webdev管理対象のオリジナルGLBモデル |
| `public/assets/models/` | Viteで配信するGLB公開コピー |
| `assets.lock.json` | 管理アセットのハッシュとサイズの固定マニフェスト |
| `game-sharing.json` | favicon、OGカバー、共有文言のメタデータ |
| `scripts/smoke.mjs` | Chromiumによる実走E2Eスモークテスト |
| `plan.md` / `TODO.md` | 実装計画と受け入れ条件 |

## 受け入れ確認済み

- `pnpm typecheck` 成功
- `pnpm test` 成功：7ファイル、37テスト
- `pnpm build` 成功：Three.js、GLB、favicon、OGメタデータを含む `dist/`
- `pnpm smoke` 成功：走行距離、タイマー、ドリフト入力、ポーズ、ゴール判定、結果画面を確認
- WebdevのTypeScriptホスト診断を登録済み
- 生成GLBとOGカバーはアセットマニフェストへ同期済み

## 共有用アート

- `assets/share/favicon.png`：Kart Novaの星型ファビコン
- `assets/share/og.png`：3DカートレースのOGカバー

## ライセンス

Three.jsはMIT、RapierはApache-2.0です。バンドルフォントのライセンスは `public/fonts/ManusCC0-LICENSE.txt` を参照してください。ゲーム内のキャラクター、コース、UI、アイテム、ロゴ、音は本プロジェクト用のオリジナルです。
