import type { Audio } from '../engine/audio'
import { CHARACTER_NAMES, COURSE_NAMES, ITEM_COLORS, KART_COLORS, type CharacterId, type CourseId, type ItemKind, type KartColorId, type RaceRun } from '../game/game'

export type Screen = 'title' | 'character' | 'course' | 'help' | 'hud' | 'pause' | 'results'
export type UiActions = {
  start(): void
  retry(): void
  pause(): void
  resume(): void
  title(): void
  chooseCourse(course: CourseId): void
  chooseCharacter(character: CharacterId): void
  chooseColor(color: KartColorId): void
}

const CHARACTERS: Array<{ id: CharacterId; icon: string; catch: string; detail: string }> = [
  { id: 'roo', icon: '🦊', catch: '風を読むスピードスター', detail: '軽快なコーナリングが得意' },
  { id: 'mimi', icon: '🐼', catch: '守りのテクニシャン', detail: '安定したドリフトと復帰力' },
  { id: 'poru', icon: '🦦', catch: '水辺のトリックスター', detail: 'アイテムを使うと少し速い' },
  { id: 'kiki', icon: '🦔', catch: 'ひらめきのコーナー職人', detail: 'ドリフトブーストが長持ち' },
]
const COLORS: Array<{ id: KartColorId; name: string }> = [
  { id: 'cyan', name: 'ノヴァシアン' }, { id: 'coral', name: 'コーラル' }, { id: 'lime', name: 'ライム' }, { id: 'violet', name: 'ヴァイオレット' }, { id: 'gold', name: 'ゴールド' },
]
const COURSES: Array<{ id: CourseId; icon: string; tag: string; detail: string }> = [
  { id: 'green', icon: '🌼', tag: 'GREEN HILL', detail: '草原・丘・橋・カラフルな花' },
  { id: 'city', icon: '🌆', tag: 'SUNSET CITY', detail: '街並み・道路・ネオン看板' },
  { id: 'sky', icon: '🌈', tag: 'SKY RAINBOW', detail: '空中道路・虹色の床・雲の上' },
]

export class Ui {
  screen: Screen = 'title'
  private readonly root: HTMLElement
  private toastTimer = 0
  private selectedCharacter: CharacterId = 'roo'
  private selectedColor: KartColorId = 'cyan'
  private selectedCourse: CourseId = 'green'

  constructor(private readonly audio: Audio, private readonly actions: UiActions) {
    this.root = document.getElementById('ui')!
    this.root.innerHTML = this.template()
    this.root.addEventListener('click', event => this.onClick(event))
    window.addEventListener('keydown', event => {
      if (event.code === 'Escape' && (this.screen === 'help' || this.screen === 'character' || this.screen === 'course')) this.show('title')
    })
    this.show('title')
  }

  show(screen: Screen): void {
    this.screen = screen
    for (const el of this.root.querySelectorAll<HTMLElement>('[data-screen]')) {
      const active = el.dataset.screen === screen
      el.classList.toggle('is-active', active)
      el.setAttribute('aria-hidden', String(!active))
    }
    this.root.dataset.activeScreen = screen
    requestAnimationFrame(() => this.root.querySelector<HTMLElement>(`[data-screen="${screen}"] button`)?.focus())
  }

  toast(text: string): void {
    const el = this.root.querySelector<HTMLElement>('.race-toast')!
    el.textContent = text
    el.classList.remove('show')
    void el.offsetWidth
    el.classList.add('show')
    window.clearTimeout(this.toastTimer)
    this.toastTimer = window.setTimeout(() => el.classList.remove('show'), 1700)
  }

  updateHud(run: RaceRun, courseName: string): void {
    this.setText('.hud-rank', String(run.position).padStart(2, '0'))
    this.setText('.hud-lap', `${Math.min(run.lap, run.totalLaps)} / ${run.totalLaps}`)
    this.setText('.hud-speed', `${Math.max(0, Math.round(run.speed * 8))}`)
    this.setText('.hud-time', this.formatTime(run.elapsed))
    this.setText('.hud-course', courseName)
    const item = this.root.querySelector<HTMLElement>('.hud-item')!
    item.textContent = run.item ? this.itemName(run.item) : 'アイテムなし'
    item.style.setProperty('--item-color', run.item ? ITEM_COLORS[run.item] : '#64708d')
    item.classList.toggle('has-item', Boolean(run.item))
    const meter = this.root.querySelector<HTMLElement>('.drift-meter i')!
    meter.style.transform = `scaleX(${Math.min(1, run.drift / 1.2)})`
    const count = this.root.querySelector<HTMLElement>('.countdown')!
    if (run.phase === 'countdown') {
      const n = Math.ceil(run.countdown)
      count.textContent = n > 0 ? String(n) : 'GO!'
      count.classList.add('show')
    } else {
      count.classList.remove('show')
    }
  }

  showResults(run: RaceRun): void {
    this.setText('.result-rank', `${run.position}位`)
    this.setText('.result-time', this.formatTime(run.finishTime ?? run.elapsed))
    this.setText('.result-course', COURSE_NAMES[run.course])
    const title = this.root.querySelector<HTMLElement>('.results-title')!
    title.textContent = run.position === 1 ? 'NOVA CHAMPION！' : run.position <= 3 ? 'ナイスラン！' : 'ゴール！'
    title.classList.toggle('champion', run.position === 1)
    this.show('results')
  }

  private onClick(event: MouseEvent): void {
    const target = (event.target as HTMLElement).closest<HTMLElement>('[data-action],[data-character],[data-color],[data-course]')
    if (!target) return
    this.audio.unlock()
    this.audio.play('ui')
    if (target.dataset.character) {
      this.selectedCharacter = target.dataset.character as CharacterId
      this.actions.chooseCharacter(this.selectedCharacter)
      this.markSelected('[data-character]', this.selectedCharacter)
      this.updateCharacterPreview()
      return
    }
    if (target.dataset.color) {
      this.selectedColor = target.dataset.color as KartColorId
      this.actions.chooseColor(this.selectedColor)
      this.markSelected('[data-color]', this.selectedColor)
      return
    }
    if (target.dataset.course) {
      this.selectedCourse = target.dataset.course as CourseId
      this.actions.chooseCourse(this.selectedCourse)
      this.markSelected('[data-course]', this.selectedCourse)
      this.updateCoursePreview()
      return
    }
    switch (target.dataset.action) {
      case 'start': this.actions.start(); break
      case 'character': this.show('character'); break
      case 'course': this.show('course'); break
      case 'help': this.show('help'); break
      case 'pause': this.actions.pause(); break
      case 'resume': this.actions.resume(); break
      case 'retry': this.actions.retry(); break
      case 'title': this.actions.title(); break
      case 'course-from-result': this.show('course'); break
    }
  }

  private updateCharacterPreview(): void {
    const data = CHARACTERS.find(c => c.id === this.selectedCharacter) ?? CHARACTERS[0]
    this.setText('.character-name', CHARACTER_NAMES[data.id])
    this.setText('.character-catch', `${data.catch} — ${data.detail}`)
    const portrait = this.root.querySelector<HTMLElement>('.character-portrait')!
    portrait.textContent = data.icon
    portrait.style.setProperty('--character-color', this.selectedColor === 'cyan' ? '#35d7ff' : KART_COLORS[this.selectedColor])
  }

  private updateCoursePreview(): void {
    const data = COURSES.find(c => c.id === this.selectedCourse) ?? COURSES[0]
    this.setText('.course-name', COURSE_NAMES[data.id])
    this.setText('.course-detail', data.detail)
    this.setText('.course-art', data.icon)
  }

  private markSelected(selector: string, value: string): void {
    for (const el of this.root.querySelectorAll<HTMLElement>(selector)) el.classList.toggle('selected', el.dataset.character === value || el.dataset.color === value || el.dataset.course === value)
  }

  private setText(selector: string, value: string): void {
    const el = this.root.querySelector<HTMLElement>(selector)
    if (el) el.textContent = value
  }

  private formatTime(seconds: number): string {
    const minutes = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    const ms = Math.floor((seconds % 1) * 100)
    return `${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}.${String(ms).padStart(2, '0')}`
  }

  private itemName(item: ItemKind): string {
    return item === 'boost' ? 'ブースト' : item === 'slime' ? 'スライムボール' : item === 'shield' ? 'シールド' : 'ミステリーボックス'
  }

  private template(): string {
    const characterCards = CHARACTERS.map(c => `<button class="choice-card character-card ${c.id === this.selectedCharacter ? 'selected' : ''}" data-character="${c.id}"><span class="choice-icon">${c.icon}</span><b>${c.catch}</b><small>${c.detail}</small></button>`).join('')
    const colorCards = COLORS.map(c => `<button class="color-choice ${c.id === this.selectedColor ? 'selected' : ''}" data-color="${c.id}" style="--swatch:${KART_COLORS[c.id]}"><i></i><span>${c.name}</span></button>`).join('')
    const courseCards = COURSES.map(c => `<button class="choice-card course-card ${c.id === this.selectedCourse ? 'selected' : ''}" data-course="${c.id}"><span class="choice-icon">${c.icon}</span><b>${COURSE_NAMES[c.id]}</b><small>${c.detail}</small><em>${c.tag}</em></button>`).join('')
    return `
      <div class="screen screen-title is-active" data-screen="title">
        <div class="title-glow"></div><div class="title-block">
          <div class="logo-mark"><span>✦</span><div><strong>KART</strong><b>NOVA</b></div></div>
          <p class="tagline">空想の道路を、オリジナル動物レーサーと駆け抜けよう。</p>
          <div class="menu main-menu">
            <button class="btn btn-primary" data-action="start"><span>レース開始</span><small>3周のCPUグランプリ</small></button>
            <button class="btn" data-action="character"><span>キャラクター選択</span></button>
            <button class="btn" data-action="course"><span>コース選択</span></button>
            <button class="btn" data-action="help"><span>操作説明</span></button>
          </div>
        </div>
        <div class="title-badge"><span>FREE PLAY</span><b>3 COURSES / 5 RACERS</b></div>
        <div class="title-tip">WASDで走る　｜　SHIFTでドリフト　｜　SPACEでアイテム</div>
      </div>

      <div class="screen screen-panel" data-screen="character">
        <div class="panel-head"><span>RACER GARAGE</span><h1>キャラクター選択</h1><p>お気に入りのレーサーとカートカラーを選ぼう。</p></div>
        <div class="character-layout"><div class="character-preview"><div class="character-portrait">🦊</div><strong class="character-name">${CHARACTER_NAMES.roo}</strong><span class="character-catch">風を読むスピードスター — 軽快なコーナリングが得意</span><div class="preview-kart" style="--kart:${KART_COLORS.cyan}"></div></div><div class="choice-grid characters">${characterCards}<div class="color-picker"><h3>カートカラー</h3><div class="color-grid">${colorCards}</div></div></div></div>
        <div class="panel-actions"><button class="btn btn-small" data-action="title"><span>タイトルへ</span></button><button class="btn btn-primary btn-small" data-action="start"><span>この設定で出走</span></button></div>
      </div>

      <div class="screen screen-panel" data-screen="course">
        <div class="panel-head"><span>COURSE SELECT</span><h1>コース選択</h1><p>走りたい景色を選んで、3周の勝負へ。</p></div>
        <div class="choice-grid courses">${courseCards}</div><div class="course-preview"><span class="course-art">🌼</span><div><strong class="course-name">グリーンヒル</strong><small class="course-detail">草原・丘・橋・カラフルな花</small></div></div>
        <div class="panel-actions"><button class="btn btn-small" data-action="title"><span>タイトルへ</span></button><button class="btn btn-primary btn-small" data-action="start"><span>このコースで出走</span></button></div>
      </div>

      <div class="screen screen-panel help-panel" data-screen="help">
        <div class="panel-head"><span>HOW TO PLAY</span><h1>操作説明</h1><p>アクセル、ライン取り、ドリフト。全部使って1位を狙おう。</p></div>
        <div class="help-grid"><div class="help-item"><kbd>W</kbd><b>アクセル</b><small>上矢印でもOK</small></div><div class="help-item"><kbd>S</kbd><b>ブレーキ / バック</b><small>下矢印でもOK</small></div><div class="help-item"><kbd>A</kbd><kbd>D</kbd><b>左右に旋回</b><small>カーブで調整</small></div><div class="help-item"><kbd>SHIFT</kbd><b>ドリフト</b><small>曲がりながら押すと加速</small></div><div class="help-item"><kbd>SPACE</kbd><b>アイテム使用</b><small>ボックスに触れてゲット</small></div><div class="help-item"><kbd>ESC</kbd><b>ポーズ</b><small>レースを一時停止</small></div></div>
        <div class="item-guide"><div><i style="--item:#ffd35c"></i><b>ブースト</b><small>短時間スピードアップ</small></div><div><i style="--item:#8bf0b4"></i><b>スライムボール</b><small>ライバルを減速</small></div><div><i style="--item:#7ef9ff"></i><b>シールド</b><small>障害物から守る</small></div><div><i style="--item:#ff83d0"></i><b>ミステリーボックス</b><small>ランダムなアイテム</small></div></div>
        <div class="panel-actions"><button class="btn btn-primary btn-small" data-action="title"><span>わかった！</span></button></div>
      </div>

      <div class="screen screen-hud" data-screen="hud">
        <div class="hud-top"><div class="hud-rank-block"><small>POSITION</small><strong class="hud-rank">01</strong><em>位</em></div><div class="hud-course-block"><small class="hud-course">グリーンヒル</small><b><span class="hud-lap">1 / 3</span> LAP</b></div><div class="hud-time-block"><small>TIME</small><strong class="hud-time">00:00.00</strong></div></div>
        <div class="hud-speed-block"><strong class="hud-speed">0</strong><span>km/h</span></div><div class="hud-item"><span>アイテムなし</span></div><div class="drift-label">DRIFT <div class="drift-meter"><i></i></div></div><div class="countdown">3</div><div class="race-toast"></div><button class="hud-pause" data-action="pause">Ⅱ</button><div class="hud-controls">W / ↑ アクセル　　A D / ← → 旋回　　SHIFT ドリフト　　SPACE アイテム</div>
      </div>

      <div class="screen screen-overlay" data-screen="pause"><div class="overlay-card"><span>RACE PAUSED</span><h1>ちょっと休憩</h1><button class="btn btn-primary" data-action="resume"><span>レースへ戻る</span></button><button class="btn" data-action="retry"><span>リトライ</span></button><button class="btn" data-action="title"><span>タイトルへ</span></button></div></div>
      <div class="screen screen-overlay" data-screen="results"><div class="overlay-card results-card"><span>FINISH LINE</span><h1 class="results-title">NOVA CHAMPION！</h1><div class="result-rank">1位</div><div class="result-row"><span>TIME</span><b class="result-time">00:00.00</b></div><div class="result-row"><span>COURSE</span><b class="result-course">グリーンヒル</b></div><button class="btn btn-primary" data-action="retry"><span>もう一度走る</span></button><button class="btn" data-action="course-from-result"><span>コースを選び直す</span></button><button class="btn" data-action="title"><span>タイトルへ</span></button></div></div>
    `
  }
}
