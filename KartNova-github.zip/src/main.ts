import './styles/main.css'
import { Audio } from './engine/audio'
import { Input } from './engine/input'
import { GameLoop } from './engine/loop'
import { Renderer, suggestQuality } from './engine/renderer'
import { Game, type CharacterId, type CourseId, type KartColorId } from './game/game'
import { Ui } from './ui/ui'

async function boot(): Promise<void> {
  const canvas = document.querySelector<HTMLCanvasElement>('#game')
  if (!canvas) throw new Error('ゲームキャンバスが見つかりません')
  const input = new Input(canvas)
  const audio = new Audio()
  const renderer = new Renderer(canvas, suggestQuality())
  let game!: Game

  const ui = new Ui(audio, {
    start: () => {
      audio.unlock()
      audio.startMusic()
      game.start()
      ui.show('hud')
    },
    retry: () => {
      audio.unlock()
      audio.startMusic()
      game.start()
      ui.show('hud')
    },
    pause: () => {
      if (game.mode === 'playing') {
        game.pause()
        ui.show('pause')
      }
    },
    resume: () => {
      if (game.mode === 'paused') {
        game.resume()
        ui.show('hud')
      }
    },
    title: () => {
      game.toTitle()
      ui.show('title')
    },
    chooseCourse: (course: CourseId) => game.selectCourse(course),
    chooseCharacter: (character: CharacterId) => game.selectCharacter(character),
    chooseColor: (color: KartColorId) => game.selectKartColor(color),
  })

  game = new Game(renderer, input, audio, {
    toast: text => ui.toast(text),
    end: run => ui.showResults(run),
  })

  const loop = new GameLoop({
    step: dt => {
      if (input.consume('pause')) {
        if (game.mode === 'playing') {
          game.pause()
          ui.show('pause')
        } else if (game.mode === 'paused') {
          game.resume()
          ui.show('hud')
        }
      }
      game.step(dt)
    },
    render: (alpha, frameSeconds) => {
      input.update()
      game.render(alpha, frameSeconds)
      if (game.mode === 'playing') ui.updateHud(game.run, game.courseName)
      input.endFrame()
    },
  })
  loop.start()

  window.addEventListener('game:pause', () => {
    if (game.mode === 'playing') {
      game.pause()
      ui.show('pause')
    }
  })
  window.addEventListener('visibilitychange', () => {
    if (document.hidden && game.mode === 'playing') {
      game.pause()
      ui.show('pause')
    }
  })

  ;(window as unknown as { __game: unknown }).__game = { game, ui, input }
  ui.show('title')
  await game.ready
}

boot().catch(error => {
  console.error(error)
  const ui = document.getElementById('ui')
  if (ui) ui.innerHTML = `<div style="display:grid;place-items:center;height:100%;padding:24px;color:#fff7d8;font:700 18px system-ui;background:#10152b">Kart Novaを起動できませんでした。ページを再読み込みしてください。<small style="display:block;margin-top:12px;opacity:.7">${String((error as Error)?.message ?? error).replace(/[<>&]/g, '')}</small></div>`
})
