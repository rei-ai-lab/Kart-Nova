import * as THREE from 'three'
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js'
import type { Audio } from '../engine/audio'
import type { Input } from '../engine/input'
import type { Renderer } from '../engine/renderer'

export type Mode = 'attract' | 'playing' | 'paused' | 'ended'
export type CourseId = 'green' | 'city' | 'sky'
export type CharacterId = 'roo' | 'mimi' | 'poru' | 'kiki'
export type KartColorId = 'cyan' | 'coral' | 'lime' | 'violet' | 'gold'
export type ItemKind = 'boost' | 'slime' | 'shield' | 'mystery'

export type RaceRun = {
  phase: 'countdown' | 'racing' | 'finished'
  elapsed: number
  countdown: number
  lap: number
  totalLaps: number
  speed: number
  position: number
  item: ItemKind | null
  drift: number
  course: CourseId
  finishTime: number | null
}

export type GameHooks = {
  toast(text: string): void
  end(run: RaceRun): void
}

type TrackPoint = { x: number; z: number; y: number }
type Track = { points: TrackPoint[]; length: number; width: number; sample: (distance: number) => { point: THREE.Vector3; tangent: THREE.Vector3; normal: THREE.Vector3 } }
type KartState = {
  root: THREE.Group
  progress: number
  speed: number
  lateral: number
  targetLateral: number
  lane: number
  character: number
  color: string
  cpu: boolean
  finished: boolean
  slowTimer: number
  shieldTimer: number
  boostTimer: number
  driftCharge: number
  driftWasActive: boolean
  lastWallToast: number
  bob: number
}
type Pickup = { group: THREE.Group; progress: number; lateral: number; active: boolean; respawnAt: number; kind: 'item' | 'coin' }
type Obstacle = { group: THREE.Object3D; progress: number; lateral: number; radius: number }
type BlobFx = { mesh: THREE.Mesh; target: KartState | null; life: number; start: THREE.Vector3 }

const TOTAL_LAPS = 3
const ROAD_WIDTH = 8.6
const COURSE_NAMES: Record<CourseId, string> = { green: 'グリーンヒル', city: 'サンセットシティ', sky: 'スカイレインボー' }
const CHARACTER_NAMES: Record<CharacterId, string> = { roo: 'ルゥ・フォックス', mimi: 'ミミ・パンダ', poru: 'ポル・カワウソ', kiki: 'キキ・ハリネズミ' }
const CHARACTER_COLORS = ['#ff8b4a', '#f7f1e1', '#a66a42', '#c08cff']
const KART_COLORS: Record<KartColorId, string> = { cyan: '#35d7ff', coral: '#ff6f61', lime: '#b7ed46', violet: '#9d7cff', gold: '#ffd35c' }
const ITEM_COLORS: Record<ItemKind, string> = { boost: '#ffd35c', slime: '#8bf0b4', shield: '#7ef9ff', mystery: '#ff83d0' }
const clamp = (n: number, min: number, max: number) => Math.max(min, Math.min(max, n))
const wrap = (n: number, max: number) => ((n % max) + max) % max
const distanceOnLoop = (a: number, b: number, length: number) => {
  const d = Math.abs(wrap(a, length) - wrap(b, length))
  return Math.min(d, length - d)
}

export class Game {
  mode: Mode = 'attract'
  readonly scene = new THREE.Scene()
  readonly camera = new THREE.PerspectiveCamera(58, 1, 0.1, 500)
  readonly run: RaceRun = { phase: 'countdown', elapsed: 0, countdown: 3, lap: 1, totalLaps: TOTAL_LAPS, speed: 0, position: 1, item: null, drift: 0, course: 'green', finishTime: null }
  readonly ready: Promise<void>
  courseId: CourseId = 'green'
  characterId: CharacterId = 'roo'
  kartColorId: KartColorId = 'cyan'
  private readonly world = new THREE.Group()
  private readonly trackVisuals = new THREE.Group()
  private readonly pickupsVisuals = new THREE.Group()
  private readonly kartsVisuals = new THREE.Group()
  private readonly effects = new THREE.Group()
  private readonly loader = new GLTFLoader()
  private readonly modelTemplates = new Map<number, THREE.Object3D>()
  private readonly rivals: KartState[] = []
  private player!: KartState
  private track!: Track
  private pickups: Pickup[] = []
  private obstacles: Obstacle[] = []
  private blobFx: BlobFx | null = null
  private pulse = 0
  private lastRank = 1
  private toastCooldown = 0
  private cameraDistance = 12
  private cameraHeight = 6.4

  constructor(private readonly renderer: Renderer, private readonly input: Input, private readonly audio: Audio, private readonly hooks: GameHooks) {
    this.scene.background = new THREE.Color('#9adcf0')
    this.scene.fog = new THREE.Fog('#9adcf0', 70, 260)
    this.scene.add(this.world, this.effects, this.kartsVisuals)
    this.world.add(this.trackVisuals, this.pickupsVisuals)
    this.scene.add(new THREE.HemisphereLight('#fff4dd', '#25516b', 2.2))
    const sun = new THREE.DirectionalLight('#fff2cf', 3.4)
    sun.position.set(-30, 50, 24)
    sun.castShadow = true
    sun.shadow.mapSize.set(1024, 1024)
    this.scene.add(sun)
    this.camera.position.set(0, 7, 14)
    this.ready = this.loadModels()
    this.buildCourse()
  }

  get courseName(): string { return COURSE_NAMES[this.courseId] }
  get characterName(): string { return CHARACTER_NAMES[this.characterId] }
  get kartColor(): string { return KART_COLORS[this.kartColorId] }

  selectCourse(course: CourseId): void {
    this.courseId = course
    this.run.course = course
    this.buildCourse()
  }

  selectCharacter(character: CharacterId): void {
    this.characterId = character
    if (this.player) {
      this.player.character = this.characterIndex(character)
      this.player.color = this.kartColor
      this.applyDriverModel(this.player)
    }
  }

  selectKartColor(color: KartColorId): void {
    this.kartColorId = color
    if (this.player) {
      this.player.color = this.kartColor
      this.recolorKart(this.player.root, this.player.color)
    }
  }

  start(): void {
    this.mode = 'playing'
    this.run.phase = 'countdown'
    this.run.elapsed = 0
    this.run.countdown = 3.15
    this.run.lap = 1
    this.run.speed = 0
    this.run.position = 1
    this.run.item = null
    this.run.drift = 0
    this.run.finishTime = null
    this.lastRank = 1
    this.toastCooldown = 0
    this.blobFx = null
    this.effects.clear()
    this.createRacers()
    this.hooks.toast('シグナルを待って！')
  }

  pause(): void { if (this.mode === 'playing') this.mode = 'paused' }
  resume(): void { if (this.mode === 'paused') this.mode = 'playing' }
  toTitle(): void { this.mode = 'attract' }

  step(dt: number): void {
    if (this.mode !== 'playing') return
    this.pulse += dt
    this.toastCooldown = Math.max(0, this.toastCooldown - dt)
    if (this.run.phase === 'countdown') {
      this.run.countdown -= dt
      if (this.run.countdown <= 0) {
        this.run.phase = 'racing'
        this.run.countdown = 0
        this.audio.play('dash')
        this.hooks.toast('GO! 走り出そう！')
      }
      this.updateVisuals(dt)
      return
    }
    if (this.run.phase !== 'racing') return
    this.run.elapsed += dt
    this.updatePlayer(dt)
    this.updateRivals(dt)
    this.updatePickups(dt)
    this.updateBlob(dt)
    this.updateRanks()
    this.run.lap = clamp(Math.floor(Math.max(0, this.player.progress) / this.track.length) + 1, 1, TOTAL_LAPS)
    this.run.speed = this.player.speed
    this.run.drift = this.player.driftCharge
    if (this.player.progress >= this.track.length * TOTAL_LAPS) {
      this.finishRace()
    }
    this.updateVisuals(dt)
  }

  render(_alpha: number, frameSeconds: number): void {
    this.pulse += frameSeconds * 0.3
    if (this.mode === 'attract') {
      const t = this.pulse * 0.18
      const sample = this.track.sample(this.track.length * 0.08)
      this.camera.position.set(sample.point.x + Math.sin(t) * 19, sample.point.y + 9 + Math.sin(t * 2) * 1.5, sample.point.z + Math.cos(t) * 19)
      this.camera.lookAt(sample.point.x, sample.point.y + 1.2, sample.point.z)
    } else {
      const p = this.track.sample(this.player?.progress ?? 0)
      const forward = p.tangent.clone().multiplyScalar(-this.cameraDistance)
      const desired = this.player?.root.position.clone().add(forward).add(new THREE.Vector3(0, this.cameraHeight, 0)) ?? new THREE.Vector3(0, 8, 14)
      this.camera.position.lerp(desired, 0.16)
      const look = (this.player?.root.position.clone() ?? new THREE.Vector3()).add(p.tangent.clone().multiplyScalar(7)).add(new THREE.Vector3(0, 1.6, 0))
      this.camera.lookAt(look)
    }
    this.animatePickups(frameSeconds)
    this.updateBlob(frameSeconds)
    this.updateVisuals(frameSeconds)
    this.renderer.render(this.scene, this.camera)
  }

  private buildCourse(): void {
    this.trackVisuals.clear()
    this.pickupsVisuals.clear()
    this.kartsVisuals.clear()
    this.world.clear()
    this.world.add(this.trackVisuals, this.pickupsVisuals)
    this.pickups = []
    this.obstacles = []
    this.track = this.makeTrack(this.courseId)
    this.buildEnvironment()
    this.buildRoad()
    this.buildPickups()
    this.buildObstacles()
    this.createPreviewKart()
  }

  private makeTrack(course: CourseId): Track {
    const raw: TrackPoint[] = course === 'green'
      ? [[0, 34, 0], [20, 30, 0], [32, 13, 1], [26, -7, 0.4], [6, -19, 1.2], [-16, -16, 0.3], [-31, -2, 1.5], [-28, 18, 0.6], [-14, 31, 2.4]] .map(([x, z, y]) => ({ x, z, y }))
      : course === 'city'
        ? [[-4, 36, 0.4], [22, 32, 0.4], [34, 13, 0.5], [24, -15, 0.4], [4, -27, 0.45], [-22, -22, 0.4], [-36, -3, 0.5], [-27, 22, 0.4]].map(([x, z, y]) => ({ x, z, y }))
        : [[0, 38, 8], [26, 30, 8.5], [32, 5, 9.5], [18, -20, 10], [-10, -27, 9.4], [-34, -11, 8.6], [-29, 17, 8], [-12, 34, 8.2]].map(([x, z, y]) => ({ x, z, y }))
    const points = raw
    let length = 0
    const lengths: number[] = []
    for (let i = 0; i < points.length; i++) {
      const a = points[i]
      const b = points[(i + 1) % points.length]
      const d = Math.hypot(b.x - a.x, b.z - a.z)
      lengths.push(d)
      length += d
    }
    const sample = (distance: number) => {
      let d = wrap(distance, length)
      let segment = 0
      while (d > lengths[segment] && segment < lengths.length - 1) { d -= lengths[segment]; segment++ }
      const a = points[segment]
      const b = points[(segment + 1) % points.length]
      const t = lengths[segment] === 0 ? 0 : d / lengths[segment]
      const point = new THREE.Vector3(THREE.MathUtils.lerp(a.x, b.x, t), THREE.MathUtils.lerp(a.y, b.y, t), THREE.MathUtils.lerp(a.z, b.z, t))
      const tangent = new THREE.Vector3(b.x - a.x, 0, b.z - a.z).normalize()
      const normal = new THREE.Vector3(-tangent.z, 0, tangent.x)
      return { point, tangent, normal }
    }
    return { points, length, width: ROAD_WIDTH, sample }
  }

  private buildRoad(): void {
    const material = new THREE.MeshStandardMaterial({ color: this.courseId === 'sky' ? '#e8f4ff' : this.courseId === 'city' ? '#30394a' : '#4a6a55', roughness: 0.78, metalness: 0.08 })
    for (let i = 0; i < this.track.points.length; i++) {
      const a = this.track.points[i]
      const b = this.track.points[(i + 1) % this.track.points.length]
      const dx = b.x - a.x
      const dz = b.z - a.z
      const len = Math.hypot(dx, dz)
      const midY = (a.y + b.y) / 2
      const road = new THREE.Mesh(new THREE.BoxGeometry(this.track.width, 0.28, len + 0.45), material)
      road.position.set((a.x + b.x) / 2, midY, (a.z + b.z) / 2)
      road.rotation.y = Math.atan2(dx, dz)
      road.receiveShadow = true
      this.trackVisuals.add(road)
      const tangent = new THREE.Vector3(dx, 0, dz).normalize()
      const normal = new THREE.Vector3(-tangent.z, 0, tangent.x)
      for (const side of [-1, 1]) {
        const wall = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.8, len + 0.45), new THREE.MeshStandardMaterial({ color: this.courseId === 'sky' ? '#d14cff' : this.courseId === 'city' ? '#5e6c85' : '#f3c24f', emissive: this.courseId === 'sky' ? '#5b127e' : '#000000', emissiveIntensity: 0.7 }))
        wall.position.set((a.x + b.x) / 2 + normal.x * (this.track.width / 2 + 0.32) * side, midY + 0.35, (a.z + b.z) / 2 + normal.z * (this.track.width / 2 + 0.32) * side)
        wall.rotation.y = Math.atan2(dx, dz)
        wall.castShadow = true
        this.trackVisuals.add(wall)
      }
      if (this.courseId === 'sky') {
        const stripe = new THREE.Mesh(new THREE.BoxGeometry(this.track.width * 0.98, 0.04, len * 0.92), new THREE.MeshBasicMaterial({ color: ['#ff5e8c', '#ffd35c', '#8bf0b4', '#7ef9ff', '#9d7cff'][i % 5] }))
        stripe.position.set((a.x + b.x) / 2, midY + 0.17, (a.z + b.z) / 2)
        stripe.rotation.y = Math.atan2(dx, dz)
        this.trackVisuals.add(stripe)
      }
    }
    this.makeLine(0, '#fff7d8', 'START')
    this.makeLine(this.track.length * 0.5, '#ff6f61', 'NOVA')
  }

  private makeLine(distance: number, color: string, label: string): void {
    const s = this.track.sample(distance)
    const line = new THREE.Group()
    const segments = 8
    for (let i = 0; i < segments; i++) {
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(this.track.width / segments - 0.04, 0.05, 0.75), new THREE.MeshBasicMaterial({ color: i % 2 ? '#10152b' : color }))
      const offset = s.normal.clone().multiplyScalar(-this.track.width / 2 + (i + 0.5) * this.track.width / segments)
      stripe.position.copy(s.point).add(offset).add(new THREE.Vector3(0, 0.18, 0))
      stripe.rotation.y = Math.atan2(s.tangent.x, s.tangent.z)
      line.add(stripe)
    }
    const arch = new THREE.Mesh(new THREE.TorusGeometry(2.8, 0.12, 8, 32, Math.PI), new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.35 }))
    arch.position.copy(s.point).add(new THREE.Vector3(0, 3, 0))
    arch.rotation.z = Math.PI / 2
    arch.rotation.y = Math.atan2(s.tangent.x, s.tangent.z)
    line.add(arch)
    const text = this.makeTextSprite(label, color)
    text.position.copy(s.point).add(new THREE.Vector3(0, 4.6, 0))
    text.scale.set(5.5, 1.4, 1)
    line.add(text)
    this.trackVisuals.add(line)
  }

  private buildEnvironment(): void {
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(240, 240), new THREE.MeshStandardMaterial({ color: this.courseId === 'city' ? '#242742' : this.courseId === 'sky' ? '#b9e9ff' : '#6bc46f', roughness: 1 }))
    ground.rotation.x = -Math.PI / 2
    ground.position.y = this.courseId === 'sky' ? -1.5 : -0.12
    ground.receiveShadow = true
    this.trackVisuals.add(ground)
    if (this.courseId === 'green') {
      for (let i = 0; i < 32; i++) {
        const p = this.track.sample(i / 32 * this.track.length)
        const flower = new THREE.Group()
        const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.06, 0.65, 6), new THREE.MeshStandardMaterial({ color: '#2f914f' }))
        stem.position.y = 0.3
        const petal = new THREE.Mesh(new THREE.SphereGeometry(0.23, 8, 6), new THREE.MeshStandardMaterial({ color: ['#ff6f91', '#ffd35c', '#7ef9ff', '#a57cff'][i % 4], emissive: ['#ff6f91', '#ffd35c', '#7ef9ff', '#a57cff'][i % 4], emissiveIntensity: 0.25 }))
        petal.position.y = 0.72
        flower.add(stem, petal)
        const offset = p.normal.clone().multiplyScalar((i % 2 ? 1 : -1) * (6 + (i % 3) * 2))
        flower.position.copy(p.point).add(offset)
        this.trackVisuals.add(flower)
      }
      this.addArch(0.28, '#b7ed46', 1.8)
    } else if (this.courseId === 'city') {
      for (let i = 0; i < 24; i++) {
        const p = this.track.sample((i + 0.5) / 24 * this.track.length)
        const h = 3 + (i % 5) * 1.3
        const building = new THREE.Mesh(new THREE.BoxGeometry(3 + (i % 2), h, 3 + ((i + 1) % 2)), new THREE.MeshStandardMaterial({ color: ['#47446a', '#363b61', '#7a4168', '#314f68'][i % 4], roughness: 0.65 }))
        building.position.copy(p.point).add(p.normal.clone().multiplyScalar((i % 2 ? 1 : -1) * 9)).setY(h / 2)
        building.castShadow = true
        this.trackVisuals.add(building)
        const neon = this.makeTextSprite(i % 2 ? 'NOVA' : 'GO!', i % 2 ? '#7ef9ff' : '#ff83d0')
        neon.position.copy(building.position).add(new THREE.Vector3(0, h * 0.2, 1.6))
        neon.scale.set(2.2, 0.65, 1)
        this.trackVisuals.add(neon)
      }
      this.addArch(0.5, '#ff83d0', 1.3)
    } else {
      for (let i = 0; i < 26; i++) {
        const cloud = new THREE.Group()
        for (let j = 0; j < 3; j++) {
          const puff = new THREE.Mesh(new THREE.SphereGeometry(1.5 + (j % 2) * 0.7, 12, 8), new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 1 }))
          puff.position.set(j * 1.5, (j % 2) * 0.45, Math.sin(j) * 0.8)
          cloud.add(puff)
        }
        cloud.position.set(-60 + (i * 17) % 120, -0.1 + (i % 3) * 0.6, -46 + ((i * 31) % 90))
        this.trackVisuals.add(cloud)
      }
      this.addArch(0.22, '#7ef9ff', 1.5)
    }
  }

  private addArch(distance: number, color: string, scale: number): void {
    const s = this.track.sample(distance * this.track.length)
    const arch = new THREE.Mesh(new THREE.TorusGeometry(3.4 * scale, 0.16, 8, 32, Math.PI), new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.6 }))
    arch.position.copy(s.point).add(new THREE.Vector3(0, 3.1, 0))
    arch.rotation.z = Math.PI / 2
    arch.rotation.y = Math.atan2(s.tangent.x, s.tangent.z)
    this.trackVisuals.add(arch)
  }

  private buildPickups(): void {
    const itemProgress = [0.12, 0.28, 0.46, 0.63, 0.8, 0.92]
    for (let i = 0; i < itemProgress.length; i++) {
      const group = new THREE.Group()
      const core = new THREE.Mesh(new THREE.OctahedronGeometry(0.65, 0), new THREE.MeshStandardMaterial({ color: '#ff83d0', emissive: '#ff2d9d', emissiveIntensity: 0.8, metalness: 0.2, roughness: 0.25 }))
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.88, 0.08, 8, 24), new THREE.MeshBasicMaterial({ color: '#fff7d8' }))
      group.add(core, ring)
      const item: Pickup = { group, progress: itemProgress[i] * this.track.length, lateral: i % 2 ? -1.8 : 1.8, active: true, respawnAt: 0, kind: 'item' }
      this.pickups.push(item)
      this.pickupsVisuals.add(group)
    }
    for (let i = 0; i < 14; i++) {
      const group = new THREE.Group()
      const coin = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.12, 16), new THREE.MeshStandardMaterial({ color: '#ffd35c', emissive: '#c68100', emissiveIntensity: 0.65, metalness: 0.55, roughness: 0.22 }))
      coin.rotation.z = Math.PI / 2
      group.add(coin)
      this.pickups.push({ group, progress: (0.06 + i / 14 * 0.9) * this.track.length, lateral: i % 2 ? 0.9 : -0.9, active: true, respawnAt: 0, kind: 'coin' })
      this.pickupsVisuals.add(group)
    }
  }

  private buildObstacles(): void {
    const values = this.courseId === 'city' ? [0.2, 0.37, 0.58, 0.77] : [0.18, 0.42, 0.67, 0.86]
    for (let i = 0; i < values.length; i++) {
      const group = new THREE.Group()
      const base = new THREE.Mesh(new THREE.CylinderGeometry(0.52, 0.68, 0.35, 10), new THREE.MeshStandardMaterial({ color: '#26354c' }))
      const top = new THREE.Mesh(new THREE.ConeGeometry(0.5, 1.2, 10), new THREE.MeshStandardMaterial({ color: i % 2 ? '#ff6f61' : '#ffd35c', emissive: i % 2 ? '#6e1d2a' : '#754f00', emissiveIntensity: 0.35 }))
      base.position.y = 0.18
      top.position.y = 0.92
      group.add(base, top)
      const lateral = (i % 3 - 1) * 2.15
      const s = this.track.sample(values[i] * this.track.length)
      group.position.copy(s.point).add(s.normal.clone().multiplyScalar(lateral))
      this.trackVisuals.add(group)
      this.obstacles.push({ group, progress: values[i] * this.track.length, lateral, radius: 1.3 })
    }
  }

  private createPreviewKart(): void {
    this.createRacers(true)
  }

  private createRacers(preview = false): void {
    this.kartsVisuals.clear()
    this.rivals.length = 0
    const playerRoot = this.makeKart(this.kartColor, this.characterIndex(this.characterId), true)
    this.player = { root: playerRoot, progress: 0, speed: 0, lateral: 0, targetLateral: 0, lane: 0, character: this.characterIndex(this.characterId), color: this.kartColor, cpu: false, finished: false, slowTimer: 0, shieldTimer: 0, boostTimer: 0, driftCharge: 0, driftWasActive: false, lastWallToast: 0, bob: 0 }
    this.kartsVisuals.add(playerRoot)
    for (let i = 0; i < 4; i++) {
      const colors = ['#ff6f61', '#b7ed46', '#9d7cff', '#ffd35c']
      const root = this.makeKart(colors[i], (i + 1) % 4, false)
      const rival: KartState = { root, progress: -5 - i * 4.2, speed: 0, lateral: (i % 2 ? -1.5 : 1.5), targetLateral: (i % 2 ? -1.5 : 1.5), lane: i, character: (i + 1) % 4, color: colors[i], cpu: true, finished: false, slowTimer: 0, shieldTimer: 0, boostTimer: 0, driftCharge: 0, driftWasActive: false, lastWallToast: 0, bob: i * 0.8 }
      this.rivals.push(rival)
      this.kartsVisuals.add(root)
    }
    this.applyDriverModel(this.player)
    for (const rival of this.rivals) this.applyDriverModel(rival)
    if (preview) {
      for (const rival of this.rivals) rival.root.visible = false
      this.player.root.visible = true
    } else {
      this.kartsVisuals.children.forEach(child => { child.visible = true })
    }
    this.updateVisuals(0)
  }

  private makeKart(color: string, character: number, player: boolean): THREE.Group {
    const root = new THREE.Group()
    const body = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.48, 3.2), new THREE.MeshStandardMaterial({ color, metalness: 0.24, roughness: 0.3 }))
    body.position.y = 0.62
    body.castShadow = true
    const nose = new THREE.Mesh(new THREE.BoxGeometry(1.35, 0.34, 1.1), new THREE.MeshStandardMaterial({ color: '#fff7d8', metalness: 0.1, roughness: 0.32 }))
    nose.position.set(0, 0.74, -1.0)
    nose.castShadow = true
    root.add(body, nose)
    for (const x of [-1.05, 1.05]) {
      for (const z of [-0.95, 0.98]) {
        const wheel = new THREE.Mesh(new THREE.CylinderGeometry(0.43, 0.43, 0.34, 14), new THREE.MeshStandardMaterial({ color: '#172035', roughness: 0.65 }))
        wheel.rotation.z = Math.PI / 2
        wheel.position.set(x, 0.42, z)
        wheel.castShadow = true
        root.add(wheel)
      }
    }
    const driver = this.makeProceduralDriver(character)
    root.add(driver)
    const light = new THREE.Mesh(new THREE.SphereGeometry(0.14, 8, 6), new THREE.MeshBasicMaterial({ color: player ? '#7ef9ff' : '#ff83d0' }))
    light.position.set(0, 0.92, 1.45)
    root.add(light)
    const shield = new THREE.Mesh(new THREE.TorusGeometry(1.5, 0.06, 8, 32), new THREE.MeshBasicMaterial({ color: '#7ef9ff', transparent: true, opacity: 0.8 }))
    shield.rotation.x = Math.PI / 2
    shield.position.y = 1
    shield.visible = false
    root.add(shield)
    root.userData.driver = driver
    root.userData.shield = shield
    root.userData.baseColor = color
    return root
  }

  private makeProceduralDriver(character: number): THREE.Group {
    const group = new THREE.Group()
    group.position.y = 1.05
    const body = new THREE.Mesh(new THREE.SphereGeometry(0.58, 12, 9), new THREE.MeshStandardMaterial({ color: CHARACTER_COLORS[character], roughness: 0.75 }))
    body.scale.set(0.84, 0.72, 0.78)
    body.castShadow = true
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.62, 14, 10), new THREE.MeshStandardMaterial({ color: CHARACTER_COLORS[character], roughness: 0.72 }))
    head.position.y = 0.68
    head.castShadow = true
    group.add(body, head)
    const eyeMaterial = new THREE.MeshBasicMaterial({ color: '#10152b' })
    for (const x of [-0.22, 0.22]) {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 6), eyeMaterial)
      eye.position.set(x, 0.76, -0.54)
      group.add(eye)
    }
    const earGeometry = character === 3 ? new THREE.ConeGeometry(0.22, 0.5, 6) : new THREE.SphereGeometry(0.25, 8, 6)
    for (const x of [-0.4, 0.4]) {
      const ear = new THREE.Mesh(earGeometry, new THREE.MeshStandardMaterial({ color: character === 1 ? '#10152b' : CHARACTER_COLORS[character], roughness: 0.7 }))
      ear.position.set(x, 1.15, 0)
      ear.rotation.z = x < 0 ? -0.18 : 0.18
      group.add(ear)
    }
    const scarf = new THREE.Mesh(new THREE.TorusGeometry(0.34, 0.09, 6, 16), new THREE.MeshStandardMaterial({ color: ['#7ef9ff', '#ff83d0', '#7ef9ff', '#b7ed46'][character], emissive: ['#7ef9ff', '#ff83d0', '#7ef9ff', '#b7ed46'][character], emissiveIntensity: 0.18 }))
    scarf.rotation.x = Math.PI / 2
    scarf.position.y = 0.5
    group.add(scarf)
    return group
  }

  private async loadModels(): Promise<void> {
    const paths = ['/assets/models/roo-fox.glb', '/assets/models/mimi-panda.glb', '/assets/models/poru-otter.glb', '/assets/models/kiki-hedgehog.glb']
    await Promise.all(paths.map(async (path, index) => {
      try {
        const gltf = await this.loader.loadAsync(path)
        const root = gltf.scene
        root.traverse(obj => {
          const mesh = obj as THREE.Mesh
          if (mesh.isMesh) { mesh.castShadow = true; mesh.receiveShadow = true }
        })
        const box = new THREE.Box3().setFromObject(root)
        const size = box.getSize(new THREE.Vector3())
        const scale = 1.65 / Math.max(size.x, size.y, size.z, 0.001)
        root.scale.setScalar(scale)
        const centered = new THREE.Box3().setFromObject(root)
        root.position.y -= centered.min.y
        this.modelTemplates.set(index, root)
        if (this.player) this.applyDriverModel(this.player)
        for (const rival of this.rivals) this.applyDriverModel(rival)
      } catch (error) {
        console.info(`Kart Nova: procedural driver fallback for ${path}`, error)
      }
    }))
  }

  private applyDriverModel(state: KartState): void {
    const template = this.modelTemplates.get(state.character)
    if (!template) return
    const old = state.root.userData.driver as THREE.Object3D | undefined
    if (old) state.root.remove(old)
    const model = template.clone(true)
    model.position.set(0, 0.35, 0)
    model.rotation.y = Math.PI
    state.root.add(model)
    state.root.userData.driver = model
  }

  private recolorKart(root: THREE.Group, color: string): void {
    root.traverse(obj => {
      const mesh = obj as THREE.Mesh
      const mat = mesh.material as THREE.MeshStandardMaterial
      if (mesh.isMesh && mat?.color && root.userData.baseColor) {
        const old = (mat.userData as { kartColor?: boolean }).kartColor
        if (old || mat.color.getHexString() === new THREE.Color(root.userData.baseColor).getHexString()) {
          mat.color.set(color)
          mat.userData.kartColor = true
        }
      }
    })
    root.userData.baseColor = color
  }

  private updatePlayer(dt: number): void {
    const accelerating = this.input.move.y > 0
    const reversing = this.input.move.y < 0
    const drifting = this.input.held('sprint') && Math.abs(this.input.move.x) > 0.1 && this.player.speed > 5
    const maxSpeed = 22 + (this.player.boostTimer > 0 ? 8 : 0)
    if (accelerating) this.player.speed += 25 * dt
    else if (reversing) this.player.speed -= 32 * dt
    else this.player.speed -= 7.5 * dt
    if (this.player.boostTimer > 0) this.player.boostTimer -= dt
    this.player.speed = clamp(this.player.speed, -5, maxSpeed)
    const steering = this.input.move.x
    const steerPower = 4.2 + Math.abs(this.player.speed) * 0.11
    this.player.lateral += steering * steerPower * dt * (drifting ? 1.28 : 1)
    if (!drifting) this.player.lateral *= Math.pow(0.72, dt * 10)
    this.player.lateral = clamp(this.player.lateral, -4.6, 4.6)
    if (drifting) {
      this.player.driftCharge = clamp(this.player.driftCharge + dt * (0.6 + Math.abs(steering)), 0, 1.5)
      this.player.driftWasActive = true
    } else if (this.player.driftWasActive) {
      if (this.player.driftCharge > 0.34) {
        this.player.boostTimer = Math.max(this.player.boostTimer, 0.5 + this.player.driftCharge * 0.25)
        this.player.speed += 5 + this.player.driftCharge * 3
        this.audio.play('dash')
        this.hooks.toast('ドリフトブースト！')
      }
      this.player.driftCharge = 0
      this.player.driftWasActive = false
    }
    this.player.progress += this.player.speed * dt
    this.player.slowTimer = Math.max(0, this.player.slowTimer - dt)
    this.player.shieldTimer = Math.max(0, this.player.shieldTimer - dt)
    this.resolveTrackBounds(this.player)
    this.resolveObstacles(this.player)
    if (this.input.consume('jump')) this.useItem()
  }

  private updateRivals(dt: number): void {
    for (const rival of this.rivals) {
      if (rival.finished) continue
      rival.slowTimer = Math.max(0, rival.slowTimer - dt)
      rival.shieldTimer = Math.max(0, rival.shieldTimer - dt)
      const target = Math.sin(this.run.elapsed * 0.65 + rival.bob) * 2.2
      rival.targetLateral = target + (rival.lane % 2 ? -0.8 : 0.8)
      rival.lateral += (rival.targetLateral - rival.lateral) * Math.min(1, dt * 1.3)
      const base = 15.0 + rival.lane * 0.55 + Math.sin(this.run.elapsed * 0.4 + rival.bob) * 0.65
      const slow = rival.slowTimer > 0 ? 0.42 : 1
      rival.speed += (base * slow - rival.speed) * Math.min(1, dt * 2.4)
      rival.progress += rival.speed * dt
      if (rival.progress >= this.track.length * TOTAL_LAPS) rival.finished = true
      this.resolveTrackBounds(rival)
      this.resolveObstacles(rival)
      if (Math.random() < dt * 0.08) {
        const item = ['boost', 'slime', 'shield'][Math.floor(Math.random() * 3)] as ItemKind
        if (item === 'boost') rival.boostTimer = 0.6
        if (item === 'slime') {
          const target = Math.abs(this.player.progress - rival.progress) < 8 ? this.player : null
          if (target && target.shieldTimer <= 0) target.slowTimer = 2.2
        }
        if (item === 'shield') rival.shieldTimer = 2.5
      }
    }
  }

  private resolveTrackBounds(state: KartState): void {
    const edge = this.track.width / 2 - 0.65
    if (Math.abs(state.lateral) > edge) {
      state.lateral = clamp(state.lateral, -edge, edge)
      state.speed *= 0.72
      if (state === this.player && this.toastCooldown <= 0) {
        this.toastCooldown = 0.8
        this.hooks.toast('ガードレールにヒット！')
        this.audio.play('hurt')
      }
    }
  }

  private resolveObstacles(state: KartState): void {
    for (const obstacle of this.obstacles) {
      if (distanceOnLoop(state.progress, obstacle.progress, this.track.length) < 1.25 && Math.abs(state.lateral - obstacle.lateral) < obstacle.radius) {
        if (state.shieldTimer <= 0) {
          state.speed *= 0.42
          state.lateral += state.lateral < obstacle.lateral ? -0.45 : 0.45
          if (state === this.player && this.toastCooldown <= 0) {
            this.toastCooldown = 0.8
            this.hooks.toast('障害物にぶつかった！')
            this.audio.play('hurt')
          }
        }
      }
    }
  }

  private updatePickups(dt: number): void {
    for (const pickup of this.pickups) {
      if (!pickup.active) {
        if (this.run.elapsed >= pickup.respawnAt) { pickup.active = true; pickup.group.visible = true }
        continue
      }
      const hit = distanceOnLoop(this.player.progress, pickup.progress, this.track.length) < 1.4 && Math.abs(this.player.lateral - pickup.lateral) < 1.6
      if (hit) {
        pickup.active = false
        pickup.respawnAt = this.run.elapsed + (pickup.kind === 'coin' ? 3.5 : 5)
        pickup.group.visible = false
        if (pickup.kind === 'coin') {
          this.hooks.toast('コイン +1')
          this.audio.play('pickup')
        } else if (!this.run.item) {
          this.run.item = Math.random() < 0.45 ? 'mystery' : (['boost', 'slime', 'shield'][Math.floor(Math.random() * 3)] as ItemKind)
          this.hooks.toast(`アイテム獲得：${this.itemLabel(this.run.item)}`)
          this.audio.play('pickup')
        } else {
          this.hooks.toast('アイテムスロットがいっぱい')
        }
      }
      for (const rival of this.rivals) {
        if (pickup.kind === 'item' && pickup.active && distanceOnLoop(rival.progress, pickup.progress, this.track.length) < 1.2 && Math.abs(rival.lateral - pickup.lateral) < 1.5) {
          pickup.active = false
          pickup.respawnAt = this.run.elapsed + 4
          pickup.group.visible = false
          rival.boostTimer = 0.45 + rival.lane * 0.05
        }
      }
    }
    if (this.player.slowTimer > 0) this.player.speed *= Math.pow(0.65, dt)
  }

  private useItem(): void {
    if (!this.run.item || this.run.phase !== 'racing') return
    let item = this.run.item
    this.run.item = null
    if (item === 'mystery') {
      item = ['boost', 'slime', 'shield'][Math.floor(Math.random() * 3)] as ItemKind
      this.hooks.toast(`ミステリーの中身：${this.itemLabel(item)}`)
    }
    if (item === 'boost') {
      this.player.boostTimer = 1.7
      this.player.speed += 8
      this.audio.play('dash')
      this.hooks.toast('ブースト！')
    } else if (item === 'shield') {
      this.player.shieldTimer = 5
      this.audio.play('pickup')
      this.hooks.toast('シールド展開！')
    } else if (item === 'slime') {
      const target = [...this.rivals].filter(r => r.progress > this.player.progress - 3).sort((a, b) => a.progress - b.progress)[0] ?? this.rivals[0]
      if (target && target.shieldTimer <= 0) target.slowTimer = 3.2
      this.spawnBlob(target)
      this.audio.play('dash')
      this.hooks.toast('スライムボール発射！')
    }
  }

  private spawnBlob(target: KartState | null): void {
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(0.42, 12, 8), new THREE.MeshStandardMaterial({ color: '#8bf0b4', emissive: '#2e8d5a', emissiveIntensity: 0.75, transparent: true, opacity: 0.92 }))
    this.effects.add(mesh)
    this.blobFx = { mesh, target, life: 0.45, start: this.player.root.position.clone().add(new THREE.Vector3(0, 1.1, -1.5)) }
  }

  private updateBlob(dt: number): void {
    if (!this.blobFx) return
    this.blobFx.life -= dt
    const target = this.blobFx.target?.root.position ?? this.player.root.position
    const t = clamp(1 - this.blobFx.life / 0.45, 0, 1)
    this.blobFx.mesh.position.lerpVectors(this.blobFx.start, target.clone().add(new THREE.Vector3(0, 0.7, 0)), t)
    this.blobFx.mesh.rotation.x += dt * 10
    if (this.blobFx.life <= 0) {
      this.effects.remove(this.blobFx.mesh)
      this.blobFx.mesh.geometry.dispose()
      ;(this.blobFx.mesh.material as THREE.Material).dispose()
      this.blobFx = null
    }
  }

  private updateRanks(): void {
    const all = [this.player, ...this.rivals]
    all.sort((a, b) => b.progress - a.progress)
    const rank = all.indexOf(this.player) + 1
    if (rank !== this.lastRank && this.toastCooldown <= 0) {
      this.hooks.toast(`${rank}位に浮上！`)
      this.toastCooldown = 1.2
    }
    this.lastRank = rank
    this.run.position = rank
  }

  private finishRace(): void {
    if (this.run.phase === 'finished') return
    this.run.phase = 'finished'
    this.run.finishTime = this.run.elapsed
    this.run.speed = 0
    this.mode = 'ended'
    this.audio.play(this.run.position === 1 ? 'win' : 'lose')
    this.hooks.toast(this.run.position === 1 ? 'NOVA CHAMPION！' : 'ゴール！')
    this.hooks.end({ ...this.run })
  }

  private updateVisuals(dt: number): void {
    if (!this.track) return
    const racers = [this.player, ...this.rivals].filter(Boolean)
    for (const racer of racers) {
      const sample = this.track.sample(racer.progress)
      const pos = sample.point.clone().add(sample.normal.clone().multiplyScalar(racer.lateral))
      racer.root.position.lerp(pos, 0.45)
      racer.root.position.y += 0.65 + Math.sin(this.pulse * 5 + racer.bob) * Math.min(0.06, Math.abs(racer.speed) * 0.002)
      racer.root.rotation.y = Math.atan2(sample.tangent.x, sample.tangent.z) + racer.lateral * 0.025
      const shield = racer.root.userData.shield as THREE.Object3D | undefined
      if (shield) shield.visible = racer.shieldTimer > 0
      const driver = racer.root.userData.driver as THREE.Object3D | undefined
      if (driver) driver.rotation.z = Math.sin(this.pulse * 8 + racer.bob) * Math.min(0.05, Math.abs(racer.speed) * 0.004)
    }
    for (const pickup of this.pickups) {
      if (!pickup.active) continue
      const s = this.track.sample(pickup.progress)
      pickup.group.position.copy(s.point).add(s.normal.clone().multiplyScalar(pickup.lateral)).add(new THREE.Vector3(0, pickup.kind === 'coin' ? 1.0 : 1.35, 0))
    }
    void dt
  }

  private animatePickups(dt: number): void {
    for (const pickup of this.pickups) {
      if (!pickup.active) continue
      pickup.group.rotation.y += dt * (pickup.kind === 'coin' ? 4.8 : 2.2)
      pickup.group.position.y += Math.sin(this.pulse * 4 + pickup.progress) * dt * 0.08
    }
  }

  private makeTextSprite(text: string, color: string): THREE.Sprite {
    const canvas = document.createElement('canvas')
    canvas.width = 256
    canvas.height = 64
    const ctx = canvas.getContext('2d')!
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.fillStyle = 'rgba(16,21,43,0.82)'
    ctx.roundRect(4, 4, 248, 56, 14)
    ctx.fill()
    ctx.strokeStyle = color
    ctx.lineWidth = 4
    ctx.stroke()
    ctx.fillStyle = '#fff7d8'
    ctx.font = 'bold 30px ManusCC0, sans-serif'
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    ctx.fillText(text, 128, 32)
    const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(canvas), transparent: true, depthWrite: false }))
    return sprite
  }

  private itemLabel(item: ItemKind): string {
    return item === 'boost' ? 'ブースト' : item === 'slime' ? 'スライムボール' : item === 'shield' ? 'シールド' : 'ミステリーボックス'
  }

  private characterIndex(character: CharacterId): number {
    return ['roo', 'mimi', 'poru', 'kiki'].indexOf(character)
  }
}

export { COURSE_NAMES, CHARACTER_NAMES, KART_COLORS, ITEM_COLORS }
