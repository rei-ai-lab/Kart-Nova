import { spawn } from 'node:child_process'
import { mkdirSync } from 'node:fs'
import { chromium } from 'playwright'

const port = 4300 + Math.floor(Math.random() * 500)
const url = `http://127.0.0.1:${port}/`
const out = process.env.SHOTS_DIR ?? 'shots'
mkdirSync(out, { recursive: true })
const server = spawn(process.execPath, ['node_modules/vite/bin/vite.js', 'preview', '--port', String(port), '--strictPort', '--host', '127.0.0.1'], { stdio: 'ignore' })
let browser
const guard = setTimeout(() => fail('timed out'), 120_000)
function cleanup() { clearTimeout(guard); try { server.kill('SIGTERM') } catch {} }
async function fail(message) { console.error(`smoke: FAIL — ${message}`); await browser?.close().catch(() => {}); cleanup(); process.exit(1) }
async function waitForServer() {
  for (let i = 0; i < 60; i += 1) {
    try { if ((await fetch(url)).ok) return } catch {}
    await new Promise(resolve => setTimeout(resolve, 250))
  }
  throw new Error('preview server did not start')
}
async function openGame(context, errors) {
  const page = await context.newPage()
  page.on('console', message => message.type() === 'error' && errors.push(message.text()))
  page.on('pageerror', error => errors.push(String(error)))
  page.on('response', response => response.status() >= 400 && errors.push(`HTTP ${response.status()} ${response.url()}`))
  await page.goto(url)
  await page.waitForSelector('[data-screen="title"].is-active', { timeout: 30_000 })
  await page.waitForTimeout(1000)
  return page
}
const state = page => page.evaluate(() => {
  const { game } = window.__game
  return { mode: game.mode, run: { ...game.run }, position: game['player']?.root?.position?.toArray?.() }
})

try {
  await waitForServer()
  browser = await chromium.launch({ args: ['--ignore-gpu-blocklist'] }).catch(() => chromium.launch({ args: ['--ignore-gpu-blocklist'], channel: 'chrome' })).catch(() => chromium.launch({ executablePath: '/usr/bin/chromium', args: ['--ignore-gpu-blocklist', '--no-sandbox'] }))
  const errors = []
  const context = await browser.newContext({ viewport: { width: 1280, height: 720 }, locale: 'ja-JP' })
  const page = await openGame(context, errors)
  await page.screenshot({ path: `${out}/01-title.png` })

  await page.click('[data-screen="title"].is-active [data-action="character"]')
  await page.waitForSelector('[data-screen="character"].is-active')
  await page.click('[data-character="mimi"]')
  await page.click('[data-color="coral"]')
  await page.screenshot({ path: `${out}/02-character.png` })
  await page.click('[data-screen="character"].is-active [data-action="title"]')
  await page.waitForSelector('[data-screen="title"].is-active')
  await page.click('[data-screen="title"].is-active [data-action="course"]')
  await page.waitForSelector('[data-screen="course"].is-active')
  await page.click('[data-course="sky"]')
  await page.screenshot({ path: `${out}/03-course.png` })
  await page.click('[data-screen="course"].is-active [data-action="start"]')
  await page.waitForSelector('[data-screen="hud"].is-active')

  const before = await state(page)
  await page.keyboard.down('KeyW')
  await page.waitForTimeout(3800)
  await page.keyboard.down('ShiftLeft')
  await page.keyboard.down('KeyA')
  await page.waitForTimeout(700)
  await page.keyboard.up('KeyA')
  await page.keyboard.up('ShiftLeft')
  await page.keyboard.up('KeyW')
  const after = await state(page)
  await page.screenshot({ path: `${out}/04-race.png` })
  const moved = Math.hypot((after.position?.[0] ?? 0) - (before.position?.[0] ?? 0), (after.position?.[2] ?? 0) - (before.position?.[2] ?? 0))
  if (after.mode !== 'playing') throw new Error(`expected playing, got ${after.mode}`)
  if (!(after.run.elapsed > 0)) throw new Error('race timer did not run')
  if (!(moved > 2)) throw new Error(`kart barely moved (${moved.toFixed(2)} m)`)
  if (!(after.run.speed >= 0)) throw new Error('speed state invalid')
  console.log(`smoke: moved ${moved.toFixed(1)}m, lap ${after.run.lap}, position ${after.run.position}`)

  await page.keyboard.press('Escape')
  await page.waitForSelector('[data-screen="pause"].is-active')
  await page.screenshot({ path: `${out}/05-pause.png` })
  await page.click('[data-screen="pause"].is-active [data-action="resume"]')
  await page.waitForSelector('[data-screen="hud"].is-active')
  const forced = await page.evaluate(() => {
    const { game } = window.__game
    game['player'].progress = game['track'].length * 3 + 100
    game.step(1 / 60)
    return { mode: game.mode, phase: game.run.phase, progress: game['player'].progress, length: game['track'].length }
  })
  console.log('smoke: finish trigger', forced)
  await page.waitForSelector('[data-screen="results"].is-active', { timeout: 10_000 })
  await page.waitForTimeout(450)
  await page.screenshot({ path: `${out}/06-results.png` })
  const done = await state(page)
  if (done.run.phase !== 'finished') throw new Error(`expected finished run, got ${done.run.phase}`)
  if (!page.locator('.result-time').textContent()) throw new Error('result time missing')

  await context.close()
  if (errors.length) throw new Error(`console errors:\n  ${errors.join('\n  ')}`)
  await browser.close()
  cleanup()
  console.log(`smoke: OK — screenshots in ${out}/`)
} catch (error) {
  await fail(error?.message ?? String(error))
}
